#define EXIT_STATUS EXIT_FAILURE
#include "true.c"
