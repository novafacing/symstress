double cl_strtod (char const *, char **restrict)
  _GL_ATTRIBUTE_NONNULL ((1));
long double cl_strtold (char const *, char **restrict)
  _GL_ATTRIBUTE_NONNULL ((1));
